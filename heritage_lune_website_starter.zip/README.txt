# Heritage Lune — starter website

Brand: Heritage Lune
Tagline: Curated Pieces From Another Time
Email: heritagelune@gmail.com
Instagram: @heritagelune
Markets: Paris and India
Sourcing: France
Focus: Vintage flasks and similar home/bar objects

## Replace before launch
1. Add real product photos.
2. Replace placeholder product names/prices.
3. Decide your checkout/payment method.
4. Add shipping, returns, condition and authenticity policies.
5. Connect the site to the registered heritagelune.com domain.
